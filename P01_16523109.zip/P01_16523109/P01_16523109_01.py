# P01_16523109_01
# NIM/Nama: 16523109/William Anthony
# Tanggal: 21-09-2023
# Kelas: 4.3.b
# Deskripsi: Program untuk memilih opsi yang memberikan uang rupiah yang lebih banyak
# Kode shift: 2-2

# KAMUS
# UP = integer
# UK = integer
# KP = integer
# UP = integer

# ALGORITMA
# INPUT
UP = int(input("Banyak uang Peng yang ditawarkan: "))
UK = int(input("Banyak uang Kom yang ditawarkan: "))
KP = int(input("Konversi mata uang Peng ke rupiah: "))
KK = int(input("Konversi mata uang Kom ke rupiah: "))
# PROSES
if UP*KP>UK*KK:
    print("Adik Tuan Kil memilih uang Peng.")
else: # UK*KK >= UP*KP (Karena ketika uangnya sama opsi diantara mereka sama saja) 
    print("Adik Tuan Kil memilih uang Kom.")