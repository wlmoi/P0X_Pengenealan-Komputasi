# P01_16523109_02
# NIM/Nama: 16523109/William Anthony
# Tanggal: 21-09-2023
# Kelas: 4.3.b
# Deskripsi: Program untuk menentukan apakah angka yang didapat Non Deb merupakan angka spesial atau tidak
# Kode shift: 2-2


# KAMUS
# A = integer berisikan 4 digit

# ALGORITMA
# INPUT
A = int(input("Masukkan Angka: ")) #A = Angka yang didapat Non Deb
# PROSES
Angka1 = A//1000 # Mengambil digit pertama
Angka2 = (A%1000)//100 # Mengambil digit kedua
Angka3 = (A%100)//10 # Mengambil digit ketiga
Angka4 = (A%10) # Mengambil digit keempat
# OUTPUT
if (Angka1*Angka4)%(Angka2+Angka3) == 0:
    print("Angka", A,"adalah angka spesial.")
else: #(Angka1*Angka4)%(Angka2+Angka3) != 0
    print("Angka", A,"bukan angka spesial.")
