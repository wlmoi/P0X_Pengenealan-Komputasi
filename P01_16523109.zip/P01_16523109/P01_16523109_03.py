# P01_16523109_03
# NIM/Nama: 16523109/William Anthony
# Tanggal: 21-09-2023
# Kelas: 4.3.b
# Deskripsi: Menghitung jumlah baju yang dapat Ia buat berdasarkan kain dan pita yang tersedia
# Kode shift: 2-2

# KAMUS
# K dan P ==  integer (kain dan pita)
# ALGORITMA
# INPUT
K = float(input("Jumlah Kain : ")) #Asumsi input Kain dalam meter
P = float(input("Jumlah Pita : ")) #Asumsi input Pita dalam meter
# PROSES
if K<3.7 or P<3.1:
    print("Bahan tidak cukup untuk membuat baju.")
else:
    L = 0
    M = 0
    S = 0
    K = K - 3.7
    P = P - 3.1 #PERSYARATAN AWAL

    if K-(2.0) or P-(1.3)>= 0:
        L += 1
        K -= 2.0
        P -= 3.1
        if K-(2.0) or P-(1.3)>= 0:
            L += 1
            K -= 2.0
            P -= 3.1
            if K-(2.0) or P-(1.3)>= 0:
                L += 1
                K -= 2.0
                P -= 3.1
                if K-(2.0) or P-(1.3)>= 0:
                    L += 1
                    K -= 2.0
                    P -= 3.1
        
    if K-(1.5) or P-(1.0)>= 0:
        M += 1
        K -= 1.5
        P -= 1.0
        if K-(1.2) or P-(0.8)>= 0:
            S += 1
            K -= 1.2
            P -= 0.8
    if K-(1.2) or P-(0.8)>= 0:
        S += 1
        K -= 1.2
        P -= 0.8
        if K-(1.2) or P-(0.8)>= 0:
            S += 1
            K -= 1.2
            P -= 0.8
 #OUTPUT   
    print("Nona Deb dapat membuat",str(S),"ukuran S,",str(M)," ukuran M,",str(L),"ukuran L.")
